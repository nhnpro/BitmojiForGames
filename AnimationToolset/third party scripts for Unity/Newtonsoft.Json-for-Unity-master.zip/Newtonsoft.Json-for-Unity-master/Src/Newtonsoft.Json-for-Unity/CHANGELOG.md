Content of this file should be copied from the CHANGELOG.md
from the repository root by the build script.

If you're seeing this, that means that script failed. :)
